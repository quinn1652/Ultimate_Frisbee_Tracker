Quinn Murphy
murphyq@wwu.edu
App: Ultimate Game Tracker

Form Page (first activity):
1. User fills in form that includes team names, score cap, and player roster
2. User presses "Start Game"

Game Page:
3. User can record when his team scores, which will lead them to a menu of players. They must select who assisted the goal and who recieved it.
4. User can record when other team scores
5. User can record when a teammate makes a defensive play or "D". They must select who made the play.

Results Page (when score cap is reached):
1. User can look at results of game and take a screenshot if they wish
2. Button on bottom of screen to "start new game"

Notes:
-Instructions are specific to each page and can be accessed via the "i" icon on the toolbar
