package quinn.apps.ultimategametracker;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.text.method.ScrollingMovementMethod;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.support.v7.widget.Toolbar;
import android.widget.Toast;

import java.util.ArrayList;

/**
 * Created by Quinn on 1/30/2018.
 */

public class SetupActivity extends AppCompatActivity {

    public static ArrayList<String> players;

    //menu stuff
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.my_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();
        if (id == R.id.instructions) {
            AlertDialog alertDialog = new AlertDialog.Builder(SetupActivity.this).create();

            alertDialog.setTitle(getString(R.string.instructions_header));
            alertDialog.setMessage(getString(R.string.instructions_setup));
            alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "OK",
                    new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.dismiss();
                        }
                    });
            alertDialog.show();
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        //setup view
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_setup);

        //toolbar
        Toolbar myToolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(myToolbar);
        myToolbar.setTitle("Game Setup");

        players=new ArrayList<String>();
        ((TextView) findViewById(R.id.textViewPlayerList)).setMovementMethod(new ScrollingMovementMethod());

        //add player button
        Button addButton = findViewById(R.id.buttonAddPlayer);
        addButton.setOnClickListener(new View.OnClickListener() {
             @Override
             public void onClick(View view) {
                 String name = ((EditText) findViewById(R.id.editTextAddPlayer)).getText().toString().trim();
                 if(name.equals("")){
                     AlertDialog alertDialog = new AlertDialog.Builder(SetupActivity.this).create();
                     alertDialog.setTitle("No Player Name");
                     alertDialog.setMessage("There is no player name to add specified in the text field");
                     alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "OK",
                             new DialogInterface.OnClickListener() {
                                 public void onClick(DialogInterface dialog, int which) {
                                     dialog.dismiss();
                                 }
                             });
                     alertDialog.show();
                 }
                 else {
                     players.add(name);
                     ((EditText) findViewById(R.id.editTextAddPlayer)).setText("");
                     String s = "";
                     for (int i = 0; i < players.size(); i++) {
                         s += players.get(i) + "\n";
                     }
                     ((TextView) findViewById(R.id.textViewPlayerList)).setText(s);
                 }
             }
        });

        //submit form button
        Button startButton = findViewById(R.id.buttonStart);
        startButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                launchGame();

            }
        });
    }

    public boolean inputCheck(String homeName, String awayName, int endScore){
        if(homeName.equals("") || awayName.equals("") || endScore < 1 || players.size() < 1){
            return false;
        }
        return true;
    }

    public void launchGame(){
        String homeName = "";
        homeName = ((EditText) findViewById(R.id.editTextHome)).getText().toString().trim();
        String awayName = "";
        awayName = ((EditText) findViewById(R.id.editTextAway)).getText().toString().trim();
        int endScore = 0;
        endScore = Integer.parseInt(((EditText) findViewById(R.id.editTextScore)).getText().toString());
//        g = new Game(homeName, awayName, endScore, players);
        if(inputCheck(homeName, awayName,endScore)){
            Intent i = new Intent(this, GameActivity.class);
            i.putExtra("homeName", homeName);
            i.putExtra("awayName", awayName);
            i.putExtra("endScore", endScore);
            i.putExtra("numPlayers", players.size());
            for(int j=0;j<players.size();j++){
                i.putExtra("p"+j, players.get(j));
            }
            startActivity(i);
        }
        else{
            AlertDialog alertDialog = new AlertDialog.Builder(SetupActivity.this).create();
            alertDialog.setTitle("Missing Input");
            alertDialog.setMessage("You are missing one or more input values (team names, score, and >0 players)");
            alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "OK",
                    new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.dismiss();
                        }
                    });
            alertDialog.show();
        }

    }
}
