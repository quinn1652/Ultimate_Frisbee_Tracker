package quinn.apps.ultimategametracker;

import java.util.ArrayList;

/**
 * Created by Quinn on 1/31/2018.
 */

public class Game{

    private String homeTeam;
    private String awayTeam;
    private int homeScore =0;
    private int awayScore =0;
    private int finScore;
    private ArrayList<Player> players;

    public Game(String homeTeam, String awayTeam, int finScore, ArrayList<Player> players){
        this.homeTeam=homeTeam;
        this.awayTeam=awayTeam;
        this.finScore=finScore;
        this.players=players;
    }

    public void addPlayer(Player p){
        players.add(p);
    }
    public void incHomeScore(){
        homeScore++;
    }
    public void incAwayScore(){
        awayScore++;
    }


    //getters

    public int getHomeScore() {
        return homeScore;
    }

    public int getAwayScore() {
        return awayScore;
    }

    public String getHomeTeam() {
        return homeTeam;
    }

    public String getAwayTeam() {
        return awayTeam;
    }

    public int getFinScore() {
        return finScore;
    }

    public ArrayList<Player> getPlayers() {
        return players;
    }

    //setters
    public void setHomeScore(int homeScore) {
        this.homeScore = homeScore;
    }

    public void setAwayScore(int awayScore) {
        this.awayScore = awayScore;
    }
}
