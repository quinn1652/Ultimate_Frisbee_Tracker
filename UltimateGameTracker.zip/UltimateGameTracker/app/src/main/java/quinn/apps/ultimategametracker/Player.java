package quinn.apps.ultimategametracker;
import java.util.Comparator;
/**
 * Created by Quinn on 1/31/2018.
 */

public class Player implements Comparable<Player> {

    private String name;
    private int g=0;
    private int a=0;
    private int d=0;

    @Override
    public int compareTo(Player other) {
        return name.compareTo(other.getName());
    }

//    public static Comparator<Player> StuNameComparator = new Comparator<Player>() {
//
//        public int compare(Player s1, Player s2) {
//            String Name1 = s1.getName().toUpperCase();
//            String Name2 = s2.getName().toUpperCase();
//
//            //ascending order
//            return Name1.compareTo(Name2);
//
//            //descending order
//            //return StudentName2.compareTo(StudentName1);
//        }};

    public Player(String name){
        this.name=name;
    }

    public void incG(){
        g++;
    }
    public void incA(){
        a++;
    }
    public void incD(){
        d++;
    }

    //setters
    public void setG(int g) {
        this.g = g;
    }

    public void setA(int a) {
        this.a = a;
    }

    public void setD(int d) {
        this.d = d;
    }


    //getters
    public String getName() {
        return name;
    }

    public int getG() {
        return g;
    }

    public int getA() {
        return a;
    }

    public int getD() {
        return d;
    }




}
