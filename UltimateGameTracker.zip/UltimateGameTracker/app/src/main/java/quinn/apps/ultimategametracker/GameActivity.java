package quinn.apps.ultimategametracker;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.text.method.ScrollingMovementMethod;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Collections;

public class GameActivity extends AppCompatActivity {
    public static Game g;

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.my_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();
        if (id == R.id.instructions) {
            AlertDialog alertDialog = new AlertDialog.Builder(GameActivity.this).create();

            alertDialog.setTitle(getString(R.string.instructions_header));
            alertDialog.setMessage(getString(R.string.instructions_game));
            alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "OK",
                    new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.dismiss();
                        }
                    });
            alertDialog.show();
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game);

        //create game object
        Intent intent = getIntent();
        final ArrayList<Player> players = new ArrayList<Player>();
        String homeName = intent.getStringExtra("homeName");
        homeName = homeName.substring(0, Math.min(homeName.length(), 10));
        String awayName = intent.getStringExtra("awayName");
        awayName = awayName.substring(0, Math.min(awayName.length(), 10));
        int endScore = intent.getIntExtra("endScore", -1);
        int numPlayers = intent.getIntExtra("numPlayers", -1);
        for(int i=0;i<numPlayers;i++){
            players.add(new Player(intent.getStringExtra("p"+i)));
        }
        Collections.sort(players);
        g = new Game(homeName, awayName, endScore, players);

        //toolbar
        Toolbar myToolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(myToolbar);
        myToolbar.setTitle(g.getHomeTeam()+" VS "+g.getAwayTeam());



        ((TextView) findViewById(R.id.textViewPlayerStats)).setMovementMethod(new ScrollingMovementMethod());
        ((TextView) findViewById(R.id.textViewGameHeader)).setText(g.getHomeTeam()+"   VS   "+g.getAwayTeam());
        ((TextView) findViewById(R.id.textViewHomeScore)).setText(g.getHomeTeam()+": "+g.getHomeScore());
        ((TextView) findViewById(R.id.textViewAwayScore)).setText(g.getAwayTeam()+": "+g.getAwayScore());

        //generate player stats
        String s = "";
        s+="Player      G   A   D\n\n";
        for(int i=0;i<players.size();i++){
            Player p = players.get(i);
            String name = p.getName();
            name = name.substring(0, Math.min(name.length(), 10));
            int namelen = name.length();
            s+=name;
            for(int j=0;j<12-namelen;j++){
                s+=" ";
            }
            s+=p.getG();
            s+="   ";
            s+=p.getA();
            s+="   ";
            s+=p.getD();
            s+="\n";
        }
        ((TextView) findViewById(R.id.textViewPlayerStats)).setText(s);


        //Your team scores button (update player stats and score)
        Button homeScoreButton = findViewById(R.id.buttonHomeScore);
        homeScoreButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //score
                g.incHomeScore();
                updateTextViews();
                if(g.getHomeScore()>=g.getFinScore()){
                    launchResults();
                }

                //player stats
                CharSequence[] names = new CharSequence[players.size()];
                for(int i=0;i<players.size();i++){
                    names[i] = players.get(i).getName();
                }

                //goal
                AlertDialog.Builder builder = new AlertDialog.Builder(GameActivity.this);
                builder.setTitle("Goal");
                builder.setItems(names, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        players.get(which).incG();
                        updateTextViews();
                    }
                });
                builder.show();

                //assist
                builder = new AlertDialog.Builder(GameActivity.this);
                builder.setTitle("Assist");
                builder.setItems(names, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        players.get(which).incA();
                        updateTextViews();
                    }
                });
                builder.show();

            }
        });

        //Other team scores button (update score)
        Button awayScoreButton = findViewById(R.id.buttonAwayScore);
        awayScoreButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                g.incAwayScore();
                updateTextViews();
                if(g.getAwayScore()>=g.getFinScore()){
                    launchResults();
                }
            }
        });

        //D button (update player stats)
        Button dButton = findViewById(R.id.buttonD);
        dButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //D
                CharSequence[] names = new CharSequence[players.size()];
                for(int i=0;i<players.size();i++){
                    names[i] = players.get(i).getName();
                }

                AlertDialog.Builder builder = new AlertDialog.Builder(GameActivity.this);
                builder.setTitle("Defensive Play");
                builder.setItems(names, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        players.get(which).incD();
                        updateTextViews();
                    }
                });
                builder.show();


            }
        });


    }

    public void updateTextViews(){


        //generate player stats
        ArrayList<Player> players = g.getPlayers();
        String s = "";
        s+="Player      G   A   D\n\n";
        for(int i=0;i<players.size();i++){
            Player p = players.get(i);
            String name = p.getName();
            name = name.substring(0, Math.min(name.length(), 10));
            int namelen = name.length();
            s+=name;
            for(int j=0;j<12-namelen;j++){
                s+=" ";
            }
            s+=p.getG();
            s+="   ";
            s+=p.getA();
            s+="   ";
            s+=p.getD();
            s+="\n";
        }
        //update
        ((TextView) findViewById(R.id.textViewPlayerStats)).setText(s);
        ((TextView) findViewById(R.id.textViewHomeScore)).setText(g.getHomeTeam()+": "+g.getHomeScore());
        ((TextView) findViewById(R.id.textViewAwayScore)).setText(g.getAwayTeam()+": "+g.getAwayScore());
    }

    public void launchResults(){
        String s = "";
        s+=g.getHomeTeam()+": "+g.getHomeScore()+"\n";
        s+=g.getAwayTeam()+": "+g.getAwayScore()+"\n\n";
        s+="Player      G   A   D\n\n";
        for(int i=0;i<g.getPlayers().size();i++){
            Player p = g.getPlayers().get(i);
            String name = p.getName();
            name = name.substring(0, Math.min(name.length(), 10));
            int namelen = name.length();
            s+=name;
            for(int j=0;j<12-namelen;j++){
                s+=" ";
            }
            s+=p.getG();
            s+="   ";
            s+=p.getA();
            s+="   ";
            s+=p.getD();
            s+="\n";
        }
        Intent i = new Intent(this, ResultsActivity.class);
        i.putExtra("Results", s);
        startActivity(i);
    }
}
